"""Build an experimental CUDA translation unit against the current local-halo solver."""
import sys
from pathlib import Path

source = Path(sys.argv[1]).read_text()
changes = [
    ('#include "local_tiles.cuh"', '#include "local_tiles.cuh"\n#include "packed_match.cuh"'),
    ('detail::LocalTilePlan plan;', 'detail::LocalTilePlan plan;\n    bool pack = false;'),
    ('plan = detail::make_local_plan(matches, n, columns, shared_limit / (2 * sizeof(int)));',
     '''plan = detail::make_local_plan(matches, n, columns, shared_limit / (2 * sizeof(int)));
            pack = !plan.left.empty() && matches.entries.size() == 4 * stride
                && plan.pitch <= shared_limit / (3 * static_cast<int>(sizeof(int)));'''),
    ('boundaries_.resize(plan.left.size());',
     '''boundaries_.resize(plan.left.size() + (pack ? stride : 0));
        if (pack) {
            auto words = detail::pack_match_offsets(matches, n);
            check(cudaMemcpy(boundaries_.data + plan.left.size(), words.data(), stride * sizeof(unsigned),
                             cudaMemcpyHostToDevice), "copy compact match offsets");
        }'''),
    ('plan.left.data(), boundaries_.bytes,', 'plan.left.data(), plan.left.size() * sizeof(int),'),
    ('} else {\n                const auto bytes = 2 * plan.pitch',
     '''} else if (pack) {
                const auto bytes = 3 * plan.pitch * sizeof(int);
                const auto words = reinterpret_cast<const unsigned*>(boundaries_.data + plan.left.size());
                detail::packed_local_tile<<<tile_blocks, threads, bytes>>>(prev, curr, indices.data,
                    boundaries_.data, words, symbols, i, count, n, columns, plan.pitch);
            } else {
                const auto bytes = 2 * plan.pitch'''),
]
for old, new in changes:
    if source.count(old) != 1:
        raise ValueError(f'unexpected CUDA source near {old}')
    source = source.replace(old, new)
Path(sys.argv[2]).write_text(source)
