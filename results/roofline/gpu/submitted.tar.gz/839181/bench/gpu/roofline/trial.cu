#include "chps/baselines.hpp"
#include "chps/cuda.hpp"
#include "chps/fasta.hpp"
#include <cuda_profiler_api.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string_view>
#include <sys/resource.h>

extern int roof_variant;
using namespace chps;
using View = std::string_view;

static void verify() {
    std::mt19937 rng(20261124);
    CudaWorkspace work;
    for (int t=0;t<102;++t) {
        const int m=t%15, n=std::array{0,1,2,15,16,31,32,33,63,64,65,255,256,257,511,513}[t%16];
        std::string a(m,'A'),b(n,'A');
        for (char& c:a) c="ACGTRYN"[rng()%7];
        for (char& c:b) c="ACGTRYN"[rng()%7];
        if (n>64 && t%3==0) {
            // Put the distant predecessor across the warp and block boundaries.
            b.assign(n,'C'); b[0]='R'; b[n-1]='R';
            a.assign(m,'R');
        }
        if (t%2) std::swap(a,b);
        auto gold=sequential(a,b,true);
        for (roof_variant=0;roof_variant<3;++roof_variant) {
            auto cost=work.distance(a,b,false), trace=work.distance(a,b,true);
            if (cost.distance!=gold.distance || trace.distance!=gold.distance || trace.cigar!=gold.cigar)
                throw std::runtime_error("differential CUDA score/trace failure");
        }
    }
    std::cout<<"102 pairs x three variants: scalar score and trace matched, including empty/odd and warp tails\n";
}

int main(int argc, char** argv) try {
    if (argc==2 && View(argv[1])=="--check") { verify(); return 0; }
    if (argc!=5) throw std::invalid_argument("METHOD INPUT.fa EXPECTED profile|time");
    View mode=argv[1];
    auto records=read_fasta(argv[2]);
    if (records.size()!=2) throw std::invalid_argument("expected two records");
    const auto& a=records[0].bases; const auto& b=records[1].bases;
    const int expected=std::stoi(argv[3]);
    bool profile=View(argv[4])=="profile";
    if (mode=="native") roof_variant=0;
    else if (mode=="fused") roof_variant=1;
    else if (mode=="shuffle") roof_variant=2;
    else if (mode!="edlib" && mode!="wfa2") throw std::invalid_argument("unknown method");
    auto score=[&]{
        if (mode=="edlib") return edlib_distance(a,b);
        if (mode=="wfa2") return wfa_distance(a,b);
        return nvpd_cuda(a,b,false);
    };
    auto warm=score();
    if (warm.distance!=expected) throw std::runtime_error("warm score mismatch");
    if (profile && cudaProfilerStart()!=cudaSuccess) throw std::runtime_error("cudaProfilerStart failed");
    const auto tick=std::chrono::steady_clock::now();
    auto timed=score();
    const auto dt=std::chrono::duration<double>(std::chrono::steady_clock::now()-tick).count();
    if (profile && cudaProfilerStop()!=cudaSuccess) throw std::runtime_error("cudaProfilerStop failed");
    if (timed.distance!=expected) throw std::runtime_error("timed score mismatch");
    rusage rss{};
    if (getrusage(RUSAGE_SELF,&rss)) throw std::runtime_error("getrusage failed");
    std::cout<<a.size()<<','<<b.size()<<','<<timed.distance<<','<<std::setprecision(12)<<dt<<','
             <<rss.ru_maxrss<<','<<timed.device_bytes<<'\n';
    return 0;
} catch (const std::exception& e) { std::cerr<<e.what()<<'\n'; return 1; }
