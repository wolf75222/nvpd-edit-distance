"""Extract two nested sets of homologous chr21 windows from chain 23."""
import argparse
from bisect import bisect_right
import csv
import gzip
import hashlib
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'scripts/datasets'))
from human_reference import CHAIN_HASH, REFS, chromosome


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('cache',type=Path,help='reference cache prepared by scripts/datasets/human_reference.py')
    p.add_argument('out',type=Path)
    args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    a,b=(chromosome(args.cache,k) for k in ('hg38','hs1'))
    chain=args.cache/'hg38ToHs1.over.chain.gz'
    if hashlib.sha256(chain.read_bytes()).hexdigest()!=CHAIN_HASH:
        raise ValueError('UCSC chain digest mismatch')
    blocks=[];active=False
    for line in gzip.open(chain,'rt'):
        cols=line.split()
        if len(cols)==13:
            active=cols[2:3]==['chr21'] and cols[4]=='+' and cols[7]=='chr21' and cols[9]=='+' and cols[12]=='23'
            if active:
                t,q=int(cols[5]),int(cols[10])
        elif active and cols:
            n=int(cols[0]);blocks.append((t,t+n,q))
            if len(cols)==3:
                t+=n+int(cols[1]);q+=n+int(cols[2])
    starts=[x[0] for x in blocks]
    def lift(k):
        i,end,j=blocks[bisect_right(starts,k)-1]
        if not i<=k<end:
            raise ValueError('endpoint falls outside aligned chain block')
        return j+k-i
    rows=[]
    for region,center in [('collinear',37400000),('insertion',33474775)]:
        for m in (16384,65536,131072,262144,524288):
            i=center-m//2;j=lift(i);end=lift(i+m)
            aa,bb=a[i:i+m],b[j:end]
            if set(aa+bb)-set(b'ACGT'):
                raise ValueError('ambiguous base in selected chromosome window')
            name=f'{region}-{m}';fa=b'>GRCh38\n'+aa+b'\n>CHM13\n'+bb+b'\n'
            (args.out/(name+'.fa')).write_bytes(fa)
            rows.append(dict(case=name,region=region,accession_a=REFS['hg38'][0],start_a=i,end_a=i+m,
                             accession_b=REFS['hs1'][0],start_b=j,end_b=end,chain_id=23,strand='+',
                             m=m,n=len(bb),input_sha256=hashlib.sha256(fa).hexdigest()))
    with (args.out/'inputs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0],lineterminator='\n');w.writeheader();w.writerows(rows)


if __name__=='__main__':main()
