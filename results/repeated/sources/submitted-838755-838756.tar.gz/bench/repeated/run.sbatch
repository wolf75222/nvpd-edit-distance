#!/bin/bash -l
#SBATCH --job-name=nvpd-repeat
#SBATCH --nodes=1
#SBATCH --mem=16G
#SBATCH --output=repeat-%j.log
set -eo pipefail
platform=${1:?expected epyc or gh200}
if [[ $platform == epyc ]]; then
    romeo_load_x64cpu_env >/dev/null
    spack load /q22mihh
elif [[ $platform == gh200 ]]; then
    romeo_load_armgpu_env >/dev/null
    spack load /phhwuh3
    spack load /dvle736
else
    exit 2
fi
set -u
build=$(mktemp -d "${TMPDIR:-/tmp}/repeat-nvpd.XXXXXX")
trap 'rm -rf -- "$build"' EXIT
out=results/repeated/jobs/$SLURM_JOB_ID
mkdir -p "$out"
opts=(-DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON "-DCMAKE_PROJECT_INCLUDE=$PWD/bench/repeated/targets.cmake")
targets=(repeat_kernel check_distances)
if [[ $platform == epyc ]]; then
    if [[ -n ${CHPS_REPEAT_INITIAL:-} ]]; then cp "$CHPS_REPEAT_INITIAL" "$build/initial.cpp"
    else git show f08b4f6fcdf81de3a6ffcd60a8934cd1aca31c83:src/dp.cpp > "$build/initial.cpp"; fi
    echo "95a75e9e3dc1d1540aafa73ba05313269fdfbcd3740453d169a3c041446d63c6  $build/initial.cpp" | sha256sum -c --status
    opts+=("-DCHPS_REPEAT_INITIAL=$build/initial.cpp" -DCMAKE_CXX_FLAGS=-march=native)
    targets+=(repeat_initial)
else
    opts+=(-DCHPS_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=90)
fi
cmake -S . -B "$build" "${opts[@]}"
cmake --build "$build" --parallel 4 --target "${targets[@]}"
export OMP_PLACES=cores OMP_PROC_BIND=close OMP_DYNAMIC=FALSE OMP_WAIT_POLICY=ACTIVE
if [[ $platform == epyc ]]; then export OMP_NUM_THREADS=8; else export OMP_NUM_THREADS=1; fi
ctest --test-dir "$build" --output-on-failure | sed "s|$build|build|g" > "$out/tests.txt"
{
  hostname -s
  g++ --version | head -1
  cmake --version | head -1
  lscpu | awk '/^(Architecture|Model name):/'
  if [[ $platform == gh200 ]]; then nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv; nvcc --version | tail -2; fi
  env | sort | sed -n '/^OMP_/p'
  cat "$build/CMakeFiles/distances.dir/flags.make" | sed -n '/^CXX_FLAGS =/p;/^CUDA_FLAGS =/p'
  sha256sum src/{dp.cpp,dp_internal.hpp,banded.cpp,baselines.cpp,cuda.cu,hirschberg.cpp} bench/repeated/{inputs.csv,kernel.cpp,measure.py,run.sbatch,targets.cmake}
} > "$out/environment.txt"
export build out platform
srun --mpi=none --cpu-bind=cores --distribution=block:block bash -c 'python3 bench/repeated/measure.py "$platform" "$build" "$out/lane-$SLURM_LOCALID.csv" --lane "$SLURM_LOCALID"'
